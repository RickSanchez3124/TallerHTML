import { Component, OnInit } from '@angular/core';
import { serie } from '../serie';
import { SerieService } from '../serie.service';

@Component({
  selector: 'app-peliculas-lista',
  templateUrl: './lista.component.html',
  styleUrls: ['./lista.component.css']
})
export class ListaComponent implements OnInit {

  series: Array<serie> = [];
  promedio: number = 0;
  suma: number = 0;


  constructor(private serieService: SerieService) { }

  getSeries(): void {
    this.serieService.getSeries().subscribe((seriex) => {
      this.series = seriex;
    });
  }

  calcularPromedio(): void {
    this.series.forEach((serie) => {
      this.suma = this.suma + serie.temporadas;

    });
    this.promedio = this.suma/(this.series.length);
  }

  ngOnInit() {
    this.getSeries();
    this.calcularPromedio();
  }

}
