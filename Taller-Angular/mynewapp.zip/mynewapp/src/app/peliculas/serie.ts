export class serie {
  id: number;
  nombre: string;
  canal: string;
  temporadas: number;
  descripcion: string;
  url: string;
  img: string;

  public constructor(id: number, nombre: string, canal: string, temporadas: number, descripcion: string, url: string, img: string) {
    this.id = id;
    this.nombre = nombre;
    this.canal = canal;
    this.temporadas = temporadas;
    this.descripcion = descripcion;
    this.url = url;
    this.img = img;
  }




}
